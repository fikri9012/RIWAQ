plugins { id("com.android.application") }

android {
    namespace = "com.riwaq.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.riwaq.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
