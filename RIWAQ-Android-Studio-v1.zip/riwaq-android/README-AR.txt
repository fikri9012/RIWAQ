رِواق RIWAQ — مشروع Android

هذه نسخة مشروع Android Studio تحتوي على واجهة رواق داخل WebView محلي.
الكتابة والحفظ التلقائي يبقيان داخل تخزين WebView المحلي على الهاتف.
التصدير والنسخ الاحتياطي يحفظان الملفات في Downloads/RIWAQ، والاسترجاع يفتح منتقي ملفات Android.
لا توجد حسابات أو Supabase أو نشر عام أو مساعد ذكي.

لإنشاء APK:
1) افتح مجلد المشروع RIWAQ في Android Studio حديث.
2) اسمح بمزامنة Gradle وتنزيل Android SDK Platform 35 عند الطلب.
3) من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4) ستجد APK عادة في app/build/outputs/apk/debug/app-debug.apk.

المتطلبات: Android Studio، JDK 17، Android SDK Platform 35، واتصال إنترنت أول مرة لتنزيل Gradle وAndroid Gradle Plugin.
الحد الأدنى المعلن Android 10 (API 29).

تنبيه: هذا أرشيف مصدر Android Studio وليس APK مثبتاً. لم يتم إنشاء APK في بيئة العمل الحالية لعدم توفر Android SDK وGradle هنا.
